EMPTY = 0
START = 2
TARGET = 3
FRONTIER = 4
EXPLORED = 5
PATH = 6


class Node:
    
    def _init_(self, row, col):
        self.row = row
        self.col = col
        self.state = EMPTY
        self.parent = None
        self.cost = 0
        self.depth = 0
    
    def _lt_(self, other):
        return self.cost < other.cost
    
    def _eq_(self, other):
        return self.row == other.row and self.col == other.col
    
    def _hash_(self):
        return hash((self.row, self.col))
    
    def _repr_(self):
        return f"Node({self.row}, {self.col})"


class Grid:
    
    def _init_(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.grid = [[Node(r, c) for c in range(cols)] for r in range(rows)]
        self.start = None
        self.target = None
    
    def reset_search_states(self):
        for row in self.grid:
            for node in row:
                if node.state in [FRONTIER, EXPLORED, PATH]:
                    node.state = EMPTY
                node.parent = None
                node.cost = 0
                node.depth = 0
    
    def set_start(self, row, col):
        if self.start:
            self.grid[self.start[0]][self.start[1]].state = EMPTY
        self.start = (row, col)
        self.grid[row][col].state = START
    
    def set_target(self, row, col):
        if self.target:
            self.grid[self.target[0]][self.target[1]].state = EMPTY
        self.target = (row, col)
        self.grid[row][col].state = TARGET
    
    def get_neighbors(self, node):
        neighbors = []
        
        directions = [
            (-1,  0), 
            ( 1,  0),   
            ( 0, -1),   
            ( 0,  1),  
            (-1, -1), 
            ( 1,  1), 
        ]
        
        for dr, dc in directions:
            new_row, new_col = node.row + dr, node.col + dc
            
            if 0 <= new_row < self.rows and 0 <= new_col < self.cols:
                neighbor = self.grid[new_row][new_col]
                cost = 1.414 if dr != 0 and dc != 0 else 1.0
                neighbors.append((neighbor, cost))
        
        return neighbors
    
    def get_node(self, row, col):
        if 0 <= row < self.rows and 0 <= col < self.cols:
            return self.grid[row][col]
        return None
    
    def clear(self):
        self.grid = [[Node(r, c) for c in range(self.cols)] for r in range(self.rows)]
        self.start = None
        self.target = None